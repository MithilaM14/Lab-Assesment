package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;


public class Admin extends JFrame implements ActionListener {
    private JPanel panel, buttonPanel;
    private JLabel titleLabel;
    private JButton addMovieBtn, deleteMovieBtn, viewBookingsBtn, manageUsersBtn, viewUsersBtn, logoutBtn;
    private Color mycolor, mycolor1;
    private Font myfont, titlefont;
    private ImageIcon img;

    public Admin() {
        super("Admin Dashboard");
        this.setSize(1100, 600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);

        mycolor  = new Color(89,23,143);
        mycolor1 = new Color(159,41,255);
        myfont   = new Font("Cambria", Font.PLAIN, 18);
        titlefont= new Font("Cambria", Font.BOLD, 24);

        panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(mycolor);

       
        titleLabel = new JLabel("Admin Dashboard", JLabel.CENTER);
        titleLabel.setFont(titlefont);
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel, BorderLayout.NORTH);

     
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(6, 1, 10, 10));
        buttonPanel.setBackground(mycolor);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 100, 20, 20));
        buttonPanel.setPreferredSize(new Dimension(1000, 400));

        addMovieBtn = new JButton("Add Movie");
        addMovieBtn.setBackground(mycolor1);
        addMovieBtn.setForeground(Color.white);
        addMovieBtn.setFont(myfont);
        addMovieBtn.setFocusPainted(false);
        addMovieBtn.addActionListener(this);
        buttonPanel.add(addMovieBtn);

        deleteMovieBtn = new JButton("Delete Movie");
        deleteMovieBtn.setBackground(mycolor1);
        deleteMovieBtn.setForeground(Color.white);
        deleteMovieBtn.setFont(myfont);
        deleteMovieBtn.setFocusPainted(false);
        deleteMovieBtn.addActionListener(this);
        buttonPanel.add(deleteMovieBtn);

        viewBookingsBtn = new JButton("View Bookings");
        viewBookingsBtn.setBackground(mycolor1);
        viewBookingsBtn.setForeground(Color.white);
        viewBookingsBtn.setFont(myfont);
        viewBookingsBtn.setFocusPainted(false);
        viewBookingsBtn.addActionListener(this);
        buttonPanel.add(viewBookingsBtn);

        manageUsersBtn = new JButton("Remove User");
        manageUsersBtn.setBackground(mycolor1);
        manageUsersBtn.setForeground(Color.white);
        manageUsersBtn.setFont(myfont);
        manageUsersBtn.setFocusPainted(false);
        manageUsersBtn.addActionListener(this);
        buttonPanel.add(manageUsersBtn);

        viewUsersBtn = new JButton("View Users");
        viewUsersBtn.setBackground(mycolor1);
        viewUsersBtn.setForeground(Color.white);
        viewUsersBtn.setFont(myfont);
        viewUsersBtn.setFocusPainted(false);
        viewUsersBtn.addActionListener(this);
        buttonPanel.add(viewUsersBtn);

        logoutBtn = new JButton("Logout");
        logoutBtn.setBackground(Color.RED);
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setFont(myfont);
        logoutBtn.setFocusPainted(false);
        logoutBtn.addActionListener(this);
        buttonPanel.add(logoutBtn);

        panel.add(buttonPanel, BorderLayout.WEST);


        img = new ImageIcon("admin.png"); 
        JLabel imglbl = new JLabel(img);
        panel.add(imglbl, BorderLayout.EAST);

        this.add(panel);
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addMovieBtn) {
            String movieName = JOptionPane.showInputDialog(this, "Enter Movie Name:");
            if (movieName != null && !movieName.trim().isEmpty()) {
                if (!movieExists(movieName)) {
                    addMovie(movieName);
                } else {
                    JOptionPane.showMessageDialog(this, "Movie already exists.");
                }
            }
        } else if (e.getSource() == deleteMovieBtn) {
            String movieName = JOptionPane.showInputDialog(this, "Enter Movie Name to Delete:");
            if (movieName != null && !movieName.trim().isEmpty()) {
                deleteMovie(movieName);
            }
        } else if (e.getSource() == viewBookingsBtn) {
            showBookings();
        } else if (e.getSource() == manageUsersBtn) {
            String email = JOptionPane.showInputDialog(this, "Enter User Name to Remove:");
            if (email != null && !email.trim().isEmpty()) {
                int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to remove user with email: " + email + "?", "Confirm Removal", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    removeUser(email);
                }
            }
        } else if (e.getSource() == viewUsersBtn) {
            showUsers();
        } else if (e.getSource() == logoutBtn) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                this.setVisible(false);
                new LoginPage();
            }
        }
    }

 
    private boolean movieExists(String movieName) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("datas/movies.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().equalsIgnoreCase(movieName)) {
                    reader.close();
                    return true;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

 
    private void addMovie(String movieName) {
        try {
            FileWriter writer = new FileWriter("datas/movies.txt", true);
            writer.write(movieName + "\n");
            writer.close();
            JOptionPane.showMessageDialog(this, "Movie added successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error adding movie: " + e.getMessage());
        }
    }

 
    private void deleteMovie(String movieName) {
        try {
            File inputFile = new File("datas/movies.txt");
            File tempFile = new File("datas/movies_temp.txt");

            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            String currentLine;
            boolean found = false;
            while ((currentLine = reader.readLine()) != null) {
                if (!currentLine.trim().equalsIgnoreCase(movieName)) {
                    writer.write(currentLine + "\n");
                } else {
                    found = true;
                }
            }

            reader.close();
            writer.close();

            if (inputFile.delete()) {
                if (tempFile.renameTo(inputFile)) {
                    if (found) {
                        JOptionPane.showMessageDialog(this, "Movie deleted successfully.");
                    } else {
                        JOptionPane.showMessageDialog(this, "Movie not found.");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Error deleting movie.");
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error deleting movie.");
        }
    }

 
    private void showBookings() {
        JFrame bookingFrame = new JFrame("Bookings");
        bookingFrame.setSize(600, 400);
        bookingFrame.setLocationRelativeTo(this);

        JTextArea bookingArea = new JTextArea();
        bookingArea.setEditable(false);
        bookingArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        try {
            BufferedReader reader = new BufferedReader(new FileReader("datas/data.txt"));
            String line;
            int count = 0;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    bookingArea.append("User " + (++count) + ":\n");
                    bookingArea.append("Name: " + parts[0] + "\n");
                    bookingArea.append("Phone: " + parts[1] + "\n");
                    bookingArea.append("Email: " + parts[2] + "\n");
                    bookingArea.append("------------------------\n");
                }
            }
            reader.close();
            if (count == 0) {
                bookingArea.setText("No users found.");
            }
        } catch (IOException e) {
            bookingArea.setText("Error loading bookings: " + e.getMessage());
        }

        JScrollPane scrollPane = new JScrollPane(bookingArea);
        bookingFrame.add(scrollPane);
        bookingFrame.setVisible(true);
    }

    
    private void showUsers() {
        JFrame userFrame = new JFrame("Manage Users");
        userFrame.setSize(400, 300);
        userFrame.setLocationRelativeTo(this);

        JTextArea userArea = new JTextArea();
        userArea.setEditable(false);
        userArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        try {
            BufferedReader reader = new BufferedReader(new FileReader("datas/data.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                userArea.append(line + "\n");
            }
            reader.close();
        } catch (IOException e) {
            userArea.setText("Error loading users.");
        }

        JScrollPane scrollPane = new JScrollPane(userArea);
        userFrame.add(scrollPane);
        userFrame.setVisible(true);
    }

 
private void removeUser(String name) {
    File inputFile = new File("datas/data.txt");
    File tempFile = new File("datas/data_temp.txt");

    boolean found = false;

    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
         BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

        String currentLine;
        while ((currentLine = reader.readLine()) != null) {
            String[] parts = currentLine.split(",");

            if (parts.length > 0 && parts[0].trim().equalsIgnoreCase(name.trim())) {
                found = true; 
            } else {
                writer.write(currentLine);
                writer.newLine();
            }
        }

    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error removing user.");
        return;
    }

    if (found) {
        inputFile.delete();
        tempFile.renameTo(inputFile);
        JOptionPane.showMessageDialog(this, "User removed successfully.");
    } else {
        tempFile.delete();
        JOptionPane.showMessageDialog(this, "User not found.");
    }
}



}


