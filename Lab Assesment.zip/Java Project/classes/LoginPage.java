package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class LoginPage extends JFrame implements ActionListener {

    private JPanel panel;
    private JLabel titleLabel, userLabel, passLabel, roleLabel;
    private JTextField userField;
    private JPasswordField passField;
    private JRadioButton userRadio, adminRadio;
    private ButtonGroup roleGroup;
    private JButton loginBtn, signUpBtn, backBtn, exitBtn;
    ImageIcon icon;
    JLabel pic;

    Color mycolor, mycolor1;

    public LoginPage() {
        super("Magic Screen");
        this.setSize(1100, 600);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(48,12,77));

        Font titleFont = new Font("Cambria", Font.BOLD, 28);
        Font labelFont = new Font("Cambria", Font.BOLD, 17);
        Font fieldFont = new Font("Cambria", Font.PLAIN, 16);
        Font btnFont   = new Font("Cambria", Font.BOLD, 16);
        mycolor = new Color(159,41,255);
        mycolor1 = new Color(110,28,176);

        titleLabel = new JLabel("LOGIN - Magic Screen Theatre");
        titleLabel.setBounds(450, 60, 500, 40);
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel);

        userLabel = new JLabel("Email");
        userLabel.setBounds(450, 200, 150, 30);
        userLabel.setFont(labelFont);
        userLabel.setForeground(Color.WHITE);
        panel.add(userLabel);

        passLabel = new JLabel("Password:");
        passLabel.setBounds(450, 250, 150, 30);
        passLabel.setFont(labelFont);
        passLabel.setForeground(Color.WHITE);
        panel.add(passLabel);

        roleLabel = new JLabel("Login As:");
        roleLabel.setBounds(450, 300, 150, 30);
        roleLabel.setFont(labelFont);
        roleLabel.setForeground(Color.WHITE);
        panel.add(roleLabel);

        userField = new JTextField();
        userField.setBounds(600, 200, 320, 30);
        userField.setFont(fieldFont);
        userField.setBackground(Color.WHITE);
        panel.add(userField);

        passField = new JPasswordField();
        passField.setBounds(600, 250, 320, 30);
        passField.setFont(fieldFont);
        passField.setBackground(Color.WHITE);
        panel.add(passField);

        userRadio = new JRadioButton("User");
        userRadio.setBounds(600, 300, 80, 30);
        userRadio.setFont(labelFont);
        userRadio.setSelected(true);
        panel.add(userRadio);

        adminRadio = new JRadioButton("Admin");
        adminRadio.setBounds(680, 300, 100, 30);
        adminRadio.setFont(labelFont);
        panel.add(adminRadio);

        roleGroup = new ButtonGroup();
        roleGroup.add(userRadio);
        roleGroup.add(adminRadio);

        loginBtn = new JButton("Login");
        loginBtn.setBounds(450, 400, 120, 35);
        loginBtn.setFont(btnFont);
        loginBtn.setBackground(mycolor1);
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);
        loginBtn.addActionListener(this);
        panel.add(loginBtn);

        signUpBtn = new JButton("Sign Up");
        signUpBtn.setBounds(600, 400, 120, 35);
        signUpBtn.setFont(btnFont);
        signUpBtn.setBackground(mycolor1);
        signUpBtn.setForeground(Color.WHITE);
        signUpBtn.setFocusPainted(false);
        signUpBtn.addActionListener(this);
        panel.add(signUpBtn);

        backBtn = new JButton("Back");
        backBtn.setBounds(750, 400, 120, 35);
        backBtn.setFont(btnFont);
        backBtn.setBackground(mycolor1);
        backBtn.setForeground(Color.WHITE);
        backBtn.addActionListener(this);
        panel.add(backBtn);

        exitBtn = new JButton("Exit");
        exitBtn.setBounds(900, 400, 80, 35);
        exitBtn.setFont(btnFont);
        exitBtn.setBackground(mycolor1);
        exitBtn.setForeground(Color.WHITE);
        exitBtn.setFocusPainted(false);
        exitBtn.addActionListener(this);
        panel.add(exitBtn);

        icon = new ImageIcon("image/log.png");
        pic = new JLabel(icon);
        pic.setBounds(0, 0, 1100, 600);
        panel.add(pic);
        add(panel);
        setVisible(true);

        this.add(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginBtn) {
            String user = userField.getText().trim();
            String pass = new String(passField.getPassword()).trim();

            if (user.isEmpty() || pass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Email/Phone and Password required!");
                return;
            }

            
            if (adminRadio.isSelected()) {
                if (validateAdmin(user, pass)) {
                    JOptionPane.showMessageDialog(this, "Admin Login Success!");
                    this.setVisible(false);
                    new Admin();
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid Admin Credentials!");
                }
            } 
            else {
                if (validateUser(user, pass)) {
                    JOptionPane.showMessageDialog(this, "User Login Success!");
                    this.setVisible(false);
                    Frontpage1.isLoggedIn = true;
                    new Frontpage1();
                    this.dispose();
                   
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid User Credentials!");
                }
            }

        } else if (e.getSource() == signUpBtn) {
            new SignUpPage();
            this.dispose();

        } else if (e.getSource() == backBtn) {
            new Frontpage1();
            this.dispose();
        } else if (e.getSource() == exitBtn) {
            System.exit(0);
        }
    }

    
    private boolean validateAdmin(String user, String pass) {
        return user.equals("admin") && pass.equals("admin"); 
    }

    
    private boolean validateUser(String user, String pass) {
        try (BufferedReader reader = new BufferedReader(new FileReader("datas/data.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userDetails = line.split(",");
                if (userDetails[2].equals(user) && userDetails[3].equals(pass)) {
                    return true;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }


}


