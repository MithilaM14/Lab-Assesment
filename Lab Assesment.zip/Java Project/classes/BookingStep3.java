package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BookingStep3 extends JFrame implements MouseListener, ActionListener
{
    JPanel panel;

    JLabel titlelbl, snackslbl, totallbl, imglbl;

    JCheckBox popcorncb, cokecb, nachoscb;

    JTextField totalfld;

    JButton calcbtn, nextbtn, backbtn, clearbtn;

    Color mycolor, mycolor1;
    Font myfont, titlefont;
    ImageIcon img;

    public BookingStep3()
    {
        super("");
        this.setSize(1100,600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mycolor  = new Color(159,41,255);
        mycolor1 = new Color(110,28,176);
        myfont   = new Font("Cambria", Font.BOLD, 20);
        titlefont= new Font("Cambria", Font.BOLD, 28);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(mycolor);

        titlelbl = new JLabel("");
        titlelbl.setBounds(120, 10, 300, 40);
        titlelbl.setFont(titlefont);
        panel.add(titlelbl);

       
        snackslbl = new JLabel("Snacks (Optional)");
        snackslbl.setBounds(300, 150, 300, 30);
        snackslbl.setFont(myfont);
        snackslbl.setForeground(Color.WHITE);
        panel.add(snackslbl);

        
        popcorncb = new JCheckBox("Popcorn (150)");
        popcorncb.setBounds(300, 200, 180, 30);
        popcorncb.setForeground(Color.BLACK);;
        popcorncb.setFont(myfont);
        panel.add(popcorncb);

        cokecb = new JCheckBox("Coke (80)");
        cokecb.setBounds(300, 250, 180, 30);
        cokecb.setForeground(Color.BLACK);;
        cokecb.setFont(myfont);
        panel.add(cokecb);

        nachoscb = new JCheckBox("Nachos (120)");
        nachoscb.setBounds(300, 300, 180, 30);
        nachoscb.setForeground(Color.BLACK);;
        nachoscb.setFont(myfont);
        panel.add(nachoscb);

        
        totallbl = new JLabel("Total");
        totallbl.setBounds(300, 350, 120, 30);
        totallbl.setForeground(Color.WHITE);
        totallbl.setFont(myfont);
        panel.add(totallbl);

        totalfld = new JTextField();
        totalfld.setBounds(430, 350, 290, 30);
        totalfld.setEditable(false);
        panel.add(totalfld);

        
        calcbtn = new JButton("Calculate");
        calcbtn.setBounds(300, 400, 120, 40);
        calcbtn.setBackground(mycolor1);
        calcbtn.setForeground(Color.WHITE);
        calcbtn.setFont(myfont);
        calcbtn.addMouseListener(this);
        calcbtn.addActionListener(this);
        panel.add(calcbtn);

        nextbtn = new JButton("Next");
        nextbtn.setBounds(430, 400, 90, 40);
        nextbtn.setBackground(mycolor1);
        nextbtn.setForeground(Color.WHITE);
        nextbtn.setFont(myfont);
        nextbtn.addMouseListener(this);
        nextbtn.addActionListener(this);
        panel.add(nextbtn);

        backbtn = new JButton("Back");
        backbtn.setBounds(530, 400, 90, 40);
        backbtn.setBackground(mycolor1);
        backbtn.setForeground(Color.WHITE);
        backbtn.setFont(myfont);
        backbtn.addMouseListener(this);
        backbtn.addActionListener(this);
        panel.add(backbtn);

        clearbtn = new JButton("Clear");
        clearbtn.setBounds(630, 400, 90, 40);
        clearbtn.setBackground(mycolor1);
        clearbtn.setForeground(Color.WHITE);
        clearbtn.setFont(myfont);
        clearbtn.addMouseListener(this);
        clearbtn.addActionListener(this);
        panel.add(clearbtn);

       
        img = new ImageIcon("image/snack.png");  
        imglbl = new JLabel(img);
        imglbl.setBounds(0, 0, 1100, 600);
        panel.add(imglbl);

        this.add(panel);
    }

   
    public void mouseClicked(MouseEvent me){}
    public void mousePressed(MouseEvent me){}
    public void mouseReleased(MouseEvent me){}

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource()==calcbtn)
        {
            calcbtn.setBackground(mycolor);
            calcbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==nextbtn)
        {
            nextbtn.setBackground(mycolor);
            nextbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor);
            backbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==clearbtn)
        {
            clearbtn.setBackground(mycolor);
            clearbtn.setForeground(Color.BLACK);
        }
    }

    public void mouseExited(MouseEvent me)
    {
        if(me.getSource()==calcbtn)
        {
            calcbtn.setBackground(mycolor1);
            calcbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==nextbtn)
        {
            nextbtn.setBackground(mycolor1);
            nextbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor1);
            backbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==clearbtn)
        {
            clearbtn.setBackground(mycolor1);
            clearbtn.setForeground(Color.WHITE);
        }
    }

    
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==calcbtn)
        {
 
    int total = 0;
    int ticketPrice = 0;
    int qty = Integer.parseInt(BookingData.qty);
    String snacks = "";

    if(BookingData.type.equals("Regular"))
    {
        ticketPrice = 300;
    }
    else if(BookingData.type.equals("VIP"))
    {
        ticketPrice = 500;
    }

   
    total = ticketPrice * qty;

  
    if(popcorncb.isSelected())
    {
        total += 150;
        snacks += "Popcorn ";
    }
    if(cokecb.isSelected())
    {
        total += 80;
        snacks += "Coke ";
    }
    if(nachoscb.isSelected())
    {
        total += 120;
        snacks += "Nachos ";
    }

    if(snacks.length()==0)
    {
        snacks = "None";
    }

   
    BookingData.snacks = snacks;
    BookingData.total  = String.valueOf(total);

    totalfld.setText(total + " Tk");
}

        
        else if(ae.getSource()==nextbtn)
        {
            if(totalfld.getText().length()==0)
            {
                JOptionPane.showMessageDialog(this, "Please Calculate Total first!");
            }
            else
            {
                this.setVisible(false);
                PaymentPage p1 = new PaymentPage();
                p1.setVisible(true);
            }
        }
        else if(ae.getSource()==backbtn)
        {
            this.setVisible(false);
            BookingStep2 b2 = new BookingStep2();
            b2.setVisible(true);
        }
        else if(ae.getSource()==clearbtn)
        {
            popcorncb.setSelected(false);
            cokecb.setSelected(false);
            nachoscb.setSelected(false);
            totalfld.setText("");

           
            BookingData.snacks = "";
            BookingData.total  = "";
        }
    }


}
