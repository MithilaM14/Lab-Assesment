package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class StrangerThings extends JFrame implements MouseListener, ActionListener
{
    JPanel panel;

    JLabel titlelbl, namelbl, phonelbl, movielbl, timelbl, imglbl;

    JTextField namefld, phonefld;

    JComboBox<String> moviecb, timecb;

    JButton nextbtn, backbtn, clearbtn;

    Color mycolor, mycolor1;
    Font myfont, titlefont;
    ImageIcon img;

    public StrangerThings()
    {
        super("Magic Screen");
        this.setSize(1100, 600);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mycolor  = new Color(159,41,255);
        mycolor1 = new Color(110,28,176);
        myfont   = new Font("Cambria", Font.BOLD, 17);
        titlefont= new Font("Cambria", Font.BOLD, 24);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(mycolor);

       
        titlelbl = new JLabel("");
        titlelbl.setBounds(120, 10, 300, 40);
        titlelbl.setFont(titlefont);
        panel.add(titlelbl);

        
        namelbl = new JLabel("Name");
        namelbl.setBounds(350, 250, 120, 30);
        namelbl.setFont(myfont);
        namelbl.setForeground(Color.WHITE);
        panel.add(namelbl);

        phonelbl = new JLabel("Phone");
        phonelbl.setBounds(350, 290, 120, 30);
        phonelbl.setFont(myfont);
        phonelbl.setForeground(Color.WHITE);
        panel.add(phonelbl);

        movielbl = new JLabel("Hall Name");
        movielbl.setBounds(350, 330, 120, 30);
        movielbl.setFont(myfont);
        movielbl.setForeground(Color.WHITE);
        panel.add(movielbl);

        timelbl = new JLabel("Show Time");
        timelbl.setBounds(350, 370, 120, 30);
        timelbl.setFont(myfont);
        timelbl.setForeground(Color.WHITE);
        panel.add(timelbl);

        
        namefld = new JTextField();
        namefld.setBounds(480, 250, 220, 30);
        panel.add(namefld);

        phonefld = new JTextField();
        phonefld.setBounds(480, 290, 220, 30);
        panel.add(phonefld);

        
        String[] movieList = {"Select", "Hall 1","Hall 2","Hall 3","Hall 4"};
        moviecb = new JComboBox<>(movieList);
        moviecb.setBounds(480, 330, 220, 30);
        panel.add(moviecb);

        String timeList[] = {"Select", "10:00 AM", "01:00 PM", "04:00 PM", "07:00 PM"};
        timecb = new JComboBox<>(timeList);
        timecb.setBounds(480, 370, 220, 30);
        panel.add(timecb);

        
        nextbtn = new JButton("Next");
        nextbtn.setBounds(350, 410, 120, 40);
        nextbtn.setBackground(mycolor1);
        nextbtn.setForeground(Color.WHITE);
        nextbtn.setFont(myfont);
        nextbtn.addMouseListener(this);
        nextbtn.addActionListener(this);
        panel.add(nextbtn);

        clearbtn = new JButton("Clear");
        clearbtn.setBounds(480, 410, 100, 40);
        clearbtn.setBackground(mycolor1);
        clearbtn.setForeground(Color.WHITE);
        clearbtn.setFont(myfont);
        clearbtn.addMouseListener(this);
        clearbtn.addActionListener(this);
        panel.add(clearbtn);

        backbtn = new JButton("Back");
        backbtn.setBounds(600, 410, 100, 40);
        backbtn.setBackground(mycolor1);
        backbtn.setForeground(Color.WHITE);
        backbtn.setFont(myfont);
        backbtn.addMouseListener(this);
        backbtn.addActionListener(this);
        panel.add(backbtn);

        
        img = new ImageIcon("image/St.png");
        imglbl = new JLabel(img);
        imglbl.setBounds(0, 0, 1100, 600);
        panel.add(imglbl);

        this.add(panel);
    }
        
    public void mouseClicked(MouseEvent me){}
    public void mousePressed(MouseEvent me){}
    public void mouseReleased(MouseEvent me){}

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource()==nextbtn)
        {
            nextbtn.setBackground(mycolor);
            nextbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==clearbtn)
        {
            clearbtn.setBackground(mycolor);
            clearbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor);
            backbtn.setForeground(Color.BLACK);
        }
    }

    public void mouseExited(MouseEvent me)
    {
        if(me.getSource()==nextbtn)
        {
            nextbtn.setBackground(mycolor1);
            nextbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==clearbtn)
        {
            clearbtn.setBackground(mycolor1);
            clearbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor1);
            backbtn.setForeground(Color.WHITE);
        }
    }



    
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==nextbtn)
        {
            String name  = namefld.getText();
            String phone = phonefld.getText();
            String movie = moviecb.getSelectedItem().toString();
            String time  = timecb.getSelectedItem().toString();

            if(name.length()==0 || phone.length()==0 ||
               movie.equals("Select") || time.equals("Select"))
            {
                JOptionPane.showMessageDialog(this, "All fields required!");
            }
            else
            {
                
                BookingData.name  = name;
                BookingData.phone = phone;
                BookingData.movie = movie;
                BookingData.time  = time;

                this.setVisible(false);
                BookingStep2 b2 = new BookingStep2();
                b2.setVisible(true);
            }
        }
        else if(ae.getSource()==clearbtn)
        {
            namefld.setText("");
            phonefld.setText("");
            moviecb.setSelectedIndex(0);
            timecb.setSelectedIndex(0);
        }
        else if(ae.getSource()==backbtn)
        {
            this.setVisible(false);
            Frontpage1 f1 = new Frontpage1();
            f1.setVisible(true);
        }
    }


}



