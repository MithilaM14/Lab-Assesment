package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BookingStep2 extends JFrame implements MouseListener, ActionListener
{
    JPanel panel;

    JLabel titlelbl, typelbl, seatlbl, qtylbl, imglbl;

    JRadioButton regularrb, viprb;
    ButtonGroup typeGroup;

    JComboBox<String> seatcb, qtycb;

    JButton nextbtn, backbtn, clearbtn;

    Color mycolor, mycolor1;
    Font myfont, titlefont;
    ImageIcon img;

    public BookingStep2()
    {
        super("Magic Screen");
        this.setSize(1100, 600);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mycolor  = new Color(159,41,255);
        mycolor1 = new Color(110,28,176);
        myfont   = new Font("Cambria", Font.BOLD, 17);
        titlefont= new Font("Cambria", Font.BOLD, 28);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(48,12,77));

        
        titlelbl = new JLabel("");
        titlelbl.setBounds(300, 10, 300, 40);
        titlelbl.setFont(titlefont);
        panel.add(titlelbl);

        
        typelbl = new JLabel("Ticket Type");
        typelbl.setBounds(300, 200, 120, 30);
        typelbl.setFont(myfont);
        typelbl.setForeground(Color.WHITE);
        panel.add(typelbl);

        seatlbl = new JLabel("Seat");
        seatlbl.setBounds(300, 250, 120, 30);
        seatlbl.setFont(myfont);
        seatlbl.setForeground(Color.WHITE);
        panel.add(seatlbl);

        qtylbl = new JLabel("Quantity");
        qtylbl.setBounds(300, 300, 120, 30);
        qtylbl.setFont(myfont);
        qtylbl.setForeground(Color.WHITE);
        panel.add(qtylbl);

        
        regularrb = new JRadioButton("Regular (300)");
        regularrb.setBounds(450, 200, 140, 30);   
        regularrb.setFont(myfont);        
        panel.add(regularrb);

        viprb = new JRadioButton("VIP (500)");
        viprb.setBounds(620, 200, 130, 30);
        viprb.setFont(myfont);
        panel.add(viprb);

        typeGroup = new ButtonGroup();
        typeGroup.add(regularrb);
        typeGroup.add(viprb);

        
        String seatList[] = {
            "Select",
            "A1","A2","A3","A4","A5","A6","A7","A8","A9","A10",
            "B1","B2","B3","B4","B5","B6","B7","B8","B9","B10"
        };
        seatcb = new JComboBox<>(seatList);
        seatcb.setBounds(450, 250, 300, 30);
        panel.add(seatcb);

        
        String qtyList[] = {"Select","1","2","3","4","5"};
        qtycb = new JComboBox<>(qtyList);
        qtycb.setBounds(450, 300, 300, 30);
        panel.add(qtycb);

        
        nextbtn = new JButton("Next");
        nextbtn.setBounds(300, 350, 120, 40);
        nextbtn.setBackground(mycolor1);
        nextbtn.setForeground(Color.WHITE);
        nextbtn.setFont(myfont);
        nextbtn.addMouseListener(this);
        nextbtn.addActionListener(this);
        panel.add(nextbtn);

        clearbtn = new JButton("Clear");
        clearbtn.setBounds(450, 350, 100, 40);
        clearbtn.setBackground(mycolor1);
        clearbtn.setForeground(Color.WHITE);
        clearbtn.setFont(myfont);
        clearbtn.addMouseListener(this);
        clearbtn.addActionListener(this);
        panel.add(clearbtn);

        backbtn = new JButton("Back");
        backbtn.setBounds(580, 350, 100, 40);
        backbtn.setBackground(mycolor1);
        backbtn.setForeground(Color.WHITE);
        backbtn.setFont(myfont);
        backbtn.addMouseListener(this);
        backbtn.addActionListener(this);
        panel.add(backbtn);

     
        img = new ImageIcon("image/Ticket.png");
        imglbl = new JLabel(img);
        imglbl.setBounds(0, 0, 1100, 600);
        panel.add(imglbl);

        this.add(panel);
    }

    
    public void mouseClicked(MouseEvent me){}
    public void mousePressed(MouseEvent me){}
    public void mouseReleased(MouseEvent me){}

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource()==nextbtn)
        {
            nextbtn.setBackground(mycolor);
            nextbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==clearbtn)
        {
            clearbtn.setBackground(mycolor);
            clearbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor);
            backbtn.setForeground(Color.BLACK);
        }
    }

    public void mouseExited(MouseEvent me)
    {
        if(me.getSource()==nextbtn)
        {
            nextbtn.setBackground(mycolor1);
            nextbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==clearbtn)
        {
            clearbtn.setBackground(mycolor1);
            clearbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor1);
            backbtn.setForeground(Color.WHITE);
        }
    }

    
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==nextbtn)
        {
            String type;
            if(regularrb.isSelected()) type = "Regular";
            else type = "VIP";

            String seat = seatcb.getSelectedItem().toString();
            String qty  = qtycb.getSelectedItem().toString();

            if(seat.equals("Select") || qty.equals("Select"))
            {
                JOptionPane.showMessageDialog(this, "Seat & Quantity required!");
            }
            else
            {
               
                BookingData.type = type;
                BookingData.seat = seat;
                BookingData.qty  = qty;

                this.setVisible(false);
                BookingStep3 b3 = new BookingStep3();
                b3.setVisible(true);
            }
        }
        else if(ae.getSource()==clearbtn)
        {
            regularrb.setSelected(true);
            seatcb.setSelectedIndex(0);
            qtycb.setSelectedIndex(0);
        }
        else if(ae.getSource()==backbtn)
        {

        }
    }


}
