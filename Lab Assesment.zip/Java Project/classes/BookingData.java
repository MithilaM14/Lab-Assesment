package classes;

public class BookingData {

    public static String name;
    public static String phone;
    public static String movie;
    public static String time;

    public static String seat;
    public static String type;
    public static String qty;

    public static String snacks;
    public static String total;
    public static String payment;
}