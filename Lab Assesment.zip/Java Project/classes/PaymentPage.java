package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PaymentPage extends JFrame implements MouseListener,  ActionListener
{
    JPanel panel;

    JLabel titlelbl, methodlbl, amtlbl, imglbl;
    JRadioButton cardrb;
    ButtonGroup payGroup;

    JTextField amountfld, cardNumberField, expiryField, cvvField;

    JButton paybtn, backbtn, cancelbtn;

    Color mycolor, mycolor1;
    Font myfont, titlefont;
    ImageIcon img;

    public PaymentPage()
    {
        super("Movie Booking - Payment");
        this.setSize(1100, 600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);

        mycolor  = new Color(159,41,255);
        mycolor1 = new Color(110,28,176);
        myfont   = new Font("Cambria", Font.BOLD, 17);
        titlefont= new Font("Cambria", Font.BOLD, 28);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(mycolor);

        titlelbl = new JLabel("");
        titlelbl.setBounds(120, 10, 300, 40);
        titlelbl.setFont(titlefont);
        panel.add(titlelbl);

        
        methodlbl = new JLabel("Payment Method");
        methodlbl.setBounds(250, 150, 160, 30);
        methodlbl.setForeground(Color.WHITE);
        methodlbl.setFont(myfont);
        panel.add(methodlbl);

        
        cardrb = new JRadioButton("Card");
        cardrb.setBounds(250, 200, 100, 30);
        cardrb.setFont(myfont);
        cardrb.setSelected(true);
        panel.add(cardrb);

        payGroup = new ButtonGroup();
        payGroup.add(cardrb); 

        amtlbl = new JLabel("Amount");
        amtlbl.setBounds(250, 250, 120, 30);
        amtlbl.setForeground(Color.WHITE);
        amtlbl.setFont(myfont);
        panel.add(amtlbl);

        amountfld = new JTextField();
        amountfld.setBounds(400, 250, 220, 30);
        amountfld.setEditable(false);

        if(BookingData.total != null && BookingData.total.length() > 0)
        {
            amountfld.setText(BookingData.total + " Tk");
        }
        else
        {
            amountfld.setText("0 Tk");
        }
        panel.add(amountfld);

       
        JLabel cardNumberLabel = new JLabel("Card Number:");
        cardNumberLabel.setBounds(250, 300, 120, 30);
        cardNumberLabel.setFont(myfont);
        cardNumberLabel.setForeground(Color.WHITE);
        panel.add(cardNumberLabel);

        cardNumberField = new JTextField();
        cardNumberField.setBounds(400, 300, 250, 30);
        panel.add(cardNumberField);

        JLabel expiryLabel = new JLabel("Expiry Date:");
        expiryLabel.setBounds(250, 340, 120, 30);
        expiryLabel.setFont(myfont);
        expiryLabel.setForeground(Color.WHITE);
        panel.add(expiryLabel);

        expiryField = new JTextField();
        expiryField.setBounds(400, 340, 250, 30);
        panel.add(expiryField);

        JLabel cvvLabel = new JLabel("CVV:");
        cvvLabel.setBounds(250, 380, 120, 30);
        cvvLabel.setFont(myfont);
        cvvLabel.setForeground(Color.WHITE);
        panel.add(cvvLabel);

        cvvField = new JTextField();
        cvvField.setBounds(400, 380, 250, 30);
        panel.add(cvvField);

       
        cardNumberLabel.setVisible(true);
        cardNumberField.setVisible(true);
        expiryLabel.setVisible(true);
        expiryField.setVisible(true);
        cvvLabel.setVisible(true);
        cvvField.setVisible(true);

        paybtn = new JButton("Pay Now");
        paybtn.setBounds(250, 430, 120, 40);
        paybtn.setBackground(mycolor1);
        paybtn.setForeground(Color.WHITE);
        paybtn.setFont(myfont);
        paybtn.addMouseListener(this);
        paybtn.addActionListener(this);
        panel.add(paybtn);

        backbtn = new JButton("Back");
        backbtn.setBounds(400, 430, 110, 40);
        backbtn.setBackground(mycolor1);
        backbtn.setForeground(Color.WHITE);
        backbtn.setFont(myfont);
        backbtn.addMouseListener(this);
        backbtn.addActionListener(this);
        panel.add(backbtn);

        cancelbtn = new JButton("Cancel");
        cancelbtn.setBounds(530, 430, 120, 40);
        cancelbtn.setBackground(mycolor1);
        cancelbtn.setForeground(Color.WHITE);
        cancelbtn.setFont(myfont);
        cancelbtn.addMouseListener(this);
        cancelbtn.addActionListener(this);
        panel.add(cancelbtn);

        img = new ImageIcon("image/pay.png");
        imglbl = new JLabel(img);
        imglbl.setBounds(0, 0, 1100, 600);
        panel.add(imglbl);

        this.add(panel);
    }

        public void mouseClicked(MouseEvent me){}
    public void mousePressed(MouseEvent me){}
    public void mouseReleased(MouseEvent me){}

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource()==paybtn)
        {
            paybtn.setBackground(mycolor);
            paybtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor);
            backbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==cancelbtn)
        {
            cancelbtn.setBackground(mycolor);
            cancelbtn.setForeground(Color.BLACK);
        }
       
    }

    public void mouseExited(MouseEvent me)
    {
        if(me.getSource()==paybtn)
        {
            paybtn.setBackground(mycolor1);
            paybtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==cancelbtn)
        {
            cancelbtn.setBackground(mycolor1);
            cancelbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor1);
            backbtn.setForeground(Color.WHITE);
        }
       
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==paybtn)
        {
            String method = "Card"; 
           
            String cardNumber = cardNumberField.getText();
            String expiry = expiryField.getText();
            String cvv = cvvField.getText();

            
            if(cardNumber.length() <1) {
                JOptionPane.showMessageDialog(this, "Invalid card number!");
                return;
            }

            
            if(expiry.length() != 5 || !expiry.contains("/")) {
                JOptionPane.showMessageDialog(this, "Invalid expiry date format (MM/YY)!");
                return;
            }

           
            if(cvv.length() <1) {
                JOptionPane.showMessageDialog(this, "Invalid CVV!");
                return;
            }

            BookingData.payment = method;

            JOptionPane.showMessageDialog(this,
                    "Payment Successful \nMethod: " + method);

            this.setVisible(false);
            TicketPage t1 = new TicketPage();
            t1.setVisible(true);
        }
        else if(ae.getSource()==backbtn)
        {
            this.setVisible(false);
            BookingStep3 b3 = new BookingStep3();
            b3.setVisible(true);
        }
        else if(ae.getSource()==cancelbtn)
        {
            System.exit(0);
        }
    }


}
