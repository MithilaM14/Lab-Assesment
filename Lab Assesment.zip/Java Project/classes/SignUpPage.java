package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class SignUpPage extends JFrame implements MouseListener, ActionListener {
    private JPanel panel;
    private JLabel titleLabel, nameLabel, phoneLabel, emailLabel, passLabel, confirmPassLabel;
    private JTextField nameField, phoneField, emailField;
    private JPasswordField passField, confirmPassField;
    private JButton createBtn, clearBtn, loginBtn, exitBtn;
    Color mycolor,mycolor1;
    ImageIcon icon;
    JLabel pic;

    public SignUpPage() {
        super("Magic Screen");
        this.setSize(1100, 600);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(48,12,77));

        Font titleFont = new Font("Cambria", Font.BOLD, 28);
        Font labelFont = new Font("Cambria", Font.BOLD, 17);
        Font fieldFont = new Font("Cambria", Font.PLAIN, 16);
        Font btnFont   = new Font("Cambria", Font.BOLD, 16);
        mycolor = new Color(110,28,176);
        mycolor1 = new Color(159,41,255);

        titleLabel = new JLabel("SIGN UP (USER) - Magic Screen Theatre");
        titleLabel.setBounds(350, 30, 600, 40);
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(Color.WHITE);
        panel.add(titleLabel);

        nameLabel = new JLabel("Name:");
        nameLabel.setBounds(400, 150, 150, 30);
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setFont(labelFont);
        panel.add(nameLabel);

        phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(400, 200, 150, 30);
        phoneLabel.setFont(labelFont);
        phoneLabel.setForeground(Color.WHITE);
        panel.add(phoneLabel);

        emailLabel = new JLabel("Email:");
        emailLabel.setBounds(400, 250, 150, 30);
        emailLabel.setFont(labelFont);
        emailLabel.setForeground(Color.WHITE);
        panel.add(emailLabel);

        passLabel = new JLabel("Password:");
        passLabel.setBounds(400, 300, 150, 30);
        passLabel.setFont(labelFont);
        passLabel.setForeground(Color.WHITE);
        panel.add(passLabel);

        confirmPassLabel = new JLabel("Confirm Password:");
        confirmPassLabel.setBounds(400, 350, 150, 30);
        confirmPassLabel.setFont(labelFont);
        confirmPassLabel.setForeground(Color.WHITE);
        panel.add(confirmPassLabel);

        nameField = new JTextField();
        nameField.setBounds(560, 150, 320, 30);
        nameField.setFont(fieldFont);
        nameField.setBackground(Color.WHITE);
        panel.add(nameField);

        phoneField = new JTextField();
        phoneField.setBounds(560, 200, 320, 30);
        phoneField.setFont(fieldFont);
        panel.add(phoneField);

        emailField = new JTextField();
        emailField.setBounds(560, 250, 320, 30);
        emailField.setFont(fieldFont);
        panel.add(emailField);

        passField = new JPasswordField();
        passField.setBounds(560, 300, 320, 30);
        passField.setFont(fieldFont);
        panel.add(passField);

        confirmPassField = new JPasswordField();
        confirmPassField.setBounds(560, 350, 320, 30);
        confirmPassField.setFont(fieldFont);
        panel.add(confirmPassField);

        createBtn = new JButton("Create Account");
        createBtn.setBounds(400, 400, 150, 35);
        createBtn.setFont(btnFont);
        createBtn.setBackground(mycolor);
        createBtn.setForeground(Color.WHITE);
        panel.add(createBtn);

        clearBtn = new JButton("Clear");
        clearBtn.setBounds(560, 400, 100, 35);
        clearBtn.setFont(btnFont);
        clearBtn.setBackground(mycolor);
        clearBtn.setForeground(Color.WHITE);        
        panel.add(clearBtn);

        loginBtn = new JButton("Go to Login");
        loginBtn.setBounds(673, 400, 130, 35);
        loginBtn.setFont(btnFont);
        loginBtn.setBackground(mycolor);
        loginBtn.setForeground(Color.WHITE);        
        panel.add(loginBtn);

        exitBtn = new JButton("Exit");
        exitBtn.setBounds(820, 400, 80, 35);
        exitBtn.setFont(btnFont);
        exitBtn.setBackground(mycolor);
        exitBtn.setForeground(Color.WHITE);        
        panel.add(exitBtn);

        createBtn.addActionListener(this);
        clearBtn.addActionListener(this);
        loginBtn.addActionListener(this);
        exitBtn.addActionListener(this);

        createBtn.addMouseListener(this);
        clearBtn.addMouseListener(this);
        loginBtn.addMouseListener(this);
        exitBtn.addMouseListener(this);

        icon = new ImageIcon("image/sign.png");
        pic = new JLabel(icon);
        pic.setBounds(0, 0, 1100, 600);
        panel.add(pic);
        add(panel);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == createBtn) {
            String name = nameField.getText().trim();
            String phone = phoneField.getText().trim();
            String email = emailField.getText().trim();
            String pass = new String(passField.getPassword());
            String cpass = new String(confirmPassField.getPassword());

            if (name.isEmpty() || phone.isEmpty() || email.isEmpty()
                    || pass.isEmpty() || cpass.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required!");
                return;
            }

            if (!pass.equals(cpass)) {
                JOptionPane.showMessageDialog(this, "Passwords do not match!");
                return;
            }

            if (!email.endsWith("@gmail.com")) {
                JOptionPane.showMessageDialog(this, "Email must be a Gmail address (end with @gmail.com)!");
                return;
            }

           
            writeUserToFile(name, phone, email, pass);

            JOptionPane.showMessageDialog(this,
                    "Account Created Successfully!\n\nName: " + name);
            clearAll();

        } else if (e.getSource() == clearBtn) {
            clearAll();

        } else if (e.getSource() == loginBtn) {
            this.setVisible(false);
            LoginPage l1 = new LoginPage();
            l1.setVisible(true); 

        } else if (e.getSource() == exitBtn) {
            System.exit(0);
        }
    }

    private void writeUserToFile(String name, String phone, String email, String pass) {
        try {
            FileWriter fw = new FileWriter("datas/data.txt", true);  
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(name + "," + phone + "," + email + "," + pass);
            bw.newLine(); 
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void clearAll() {
        nameField.setText("");
        phoneField.setText("");
        emailField.setText("");
        passField.setText("");
        confirmPassField.setText("");
        nameField.requestFocus();
    }

    public void mouseClicked(MouseEvent me){}
    public void mousePressed(MouseEvent me){}
    public void mouseReleased(MouseEvent me){}

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource()==loginBtn)
        {
            loginBtn.setBackground(mycolor);
            loginBtn.setForeground(Color.BLACK);
        }
        
    }

    public void mouseExited(MouseEvent me)
    {
        if(me.getSource()==loginBtn)
        {
            loginBtn.setBackground(mycolor1);
            loginBtn.setForeground(Color.WHITE);
        }
       
    }


}
