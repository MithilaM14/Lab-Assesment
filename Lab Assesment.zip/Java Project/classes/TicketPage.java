package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TicketPage extends JFrame implements MouseListener, ActionListener
{
    JPanel panel;

    JLabel titlelbl, movielbl, timelbl, seatlbl, typelbl, qtylbl, totallbl, imglbl;
    JLabel movieval, timeval, seatval, typeval, qtyval, totalval;

    JButton printbtn, exitbtn, backbtn;

    Color mycolor, mycolor1;
    Font myfont, titlefont, valuefont;
    ImageIcon img;

    public TicketPage()
    {
        super("Movie Booking - Ticket");
        this.setSize(1100, 600);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);

        mycolor  = new Color(14,230,220);
        mycolor1 = new Color(110,28,176);
        myfont   = new Font("Cambria", Font.BOLD, 20);
        valuefont= new Font("Cambria", Font.BOLD, 20);
        titlefont= new Font("Cambria", Font.BOLD, 35);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(mycolor);

       
        titlelbl = new JLabel("TICKET");
        titlelbl.setBounds(420, 50, 300, 40);
        titlelbl.setFont(titlefont);
        titlelbl.setForeground(Color.WHITE);
        panel.add(titlelbl);

       
        movielbl = new JLabel("Movie");
        movielbl.setBounds(300, 150, 120, 30);
        movielbl.setForeground(Color.WHITE);
        movielbl.setFont(myfont);
        panel.add(movielbl);

        timelbl = new JLabel("Show Time");
        timelbl.setBounds(300, 200, 120, 30);
        timelbl.setForeground(Color.WHITE);
        timelbl.setFont(myfont);
        panel.add(timelbl);

        seatlbl = new JLabel("Seat");
        seatlbl.setBounds(300, 250, 120, 30);
        seatlbl.setForeground(Color.WHITE);
        seatlbl.setFont(myfont);
        panel.add(seatlbl);

        typelbl = new JLabel("Ticket Type");
        typelbl.setBounds(300, 300, 120, 30);
        typelbl.setForeground(Color.WHITE);
        typelbl.setFont(myfont);
        panel.add(typelbl);

        qtylbl = new JLabel("Quantity");
        qtylbl.setBounds(300, 350, 120, 30);
        qtylbl.setForeground(Color.WHITE);
        qtylbl.setFont(myfont);
        panel.add(qtylbl);

        totallbl = new JLabel("Total");
        totallbl.setBounds(300, 400, 120, 30);
        totallbl.setForeground(Color.WHITE);
        totallbl.setFont(myfont);
        panel.add(totallbl);

       
        movieval = new JLabel(BookingData.movie);
        movieval.setBounds(450, 150, 300, 30);
        movieval.setFont(valuefont);
        movieval.setForeground(Color.WHITE);
        panel.add(movieval);

        timeval = new JLabel(BookingData.time);
        timeval.setBounds(450, 200, 300, 30);
        timeval.setFont(valuefont);
        timeval.setForeground(Color.WHITE);
        panel.add(timeval);

        seatval = new JLabel(BookingData.seat);
        seatval.setBounds(450, 250, 300, 30);
        seatval.setFont(valuefont);
        seatval.setForeground(Color.WHITE);
        panel.add(seatval);

        typeval = new JLabel(BookingData.type);
        typeval.setBounds(450, 300, 300, 30);
        typeval.setFont(valuefont);
        typeval.setForeground(Color.WHITE);
        panel.add(typeval);

        qtyval = new JLabel(BookingData.qty);
        qtyval.setBounds(450, 350, 300, 30);
        qtyval.setFont(valuefont);
        qtyval.setForeground(Color.WHITE);
        panel.add(qtyval);

        totalval = new JLabel(BookingData.total + " Tk");
        totalval.setBounds(450, 400, 300, 30);
        totalval.setFont(valuefont);
        totalval.setForeground(Color.WHITE);
        panel.add(totalval);

       
        printbtn = new JButton("Print");
        printbtn.setBounds(300, 450, 120, 40);
        printbtn.setBackground(mycolor1);
        printbtn.setForeground(Color.WHITE);
        printbtn.setFont(myfont);
        printbtn.addActionListener(this);
        panel.add(printbtn);

        backbtn = new JButton("Back");
        backbtn.setBounds(450, 450, 100, 40);
        backbtn.setBackground(mycolor1);
        backbtn.setForeground(Color.WHITE);
        backbtn.setFont(myfont);
        backbtn.addActionListener(this);
        panel.add(backbtn);

        exitbtn = new JButton("Exit");
        exitbtn.setBounds(600, 450, 100, 40);
        exitbtn.setBackground(mycolor1);
        exitbtn.setForeground(Color.WHITE);
        exitbtn.setFont(myfont);
        exitbtn.addActionListener(this);
        panel.add(exitbtn);

       
        img = new ImageIcon("image/tic.png");
        imglbl = new JLabel(img);
        imglbl.setBounds(0, 0, 1100, 600);
        panel.add(imglbl);

        this.add(panel);
    }

    
    public void mouseClicked(MouseEvent me){}
    public void mousePressed(MouseEvent me){}
    public void mouseReleased(MouseEvent me){}

    public void mouseEntered(MouseEvent me)
    {
        if(me.getSource()==printbtn)
        {
            printbtn.setBackground(Color.GREEN);
            printbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(Color.BLUE);
            backbtn.setForeground(Color.BLACK);
        }
        else if(me.getSource()==exitbtn)
        {
            exitbtn.setBackground(Color.RED);
            exitbtn.setForeground(Color.BLACK);
        }
    }

    public void mouseExited(MouseEvent me)
    {
        if(me.getSource()==printbtn)
        {
            printbtn.setBackground(mycolor1);
            printbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==backbtn)
        {
            backbtn.setBackground(mycolor1);
            backbtn.setForeground(Color.WHITE);
        }
        else if(me.getSource()==exitbtn)
        {
            exitbtn.setBackground(mycolor1);
            exitbtn.setForeground(Color.WHITE);
        }
    }

   
    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource()==printbtn)
        {
            JOptionPane.showMessageDialog(this, "Ticket Printed Successfully");
        }
        else if(ae.getSource()==backbtn)
        {
            this.setVisible(false);
            PaymentPage p1 = new PaymentPage();
            p1.setVisible(true);
        }
        else if(ae.getSource()==exitbtn)
        {
            System.exit(0);
        }
    }


}

