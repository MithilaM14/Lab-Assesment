package classes;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Frontpage1  extends JFrame implements ActionListener, MouseListener {
    JPanel panel;
    JLabel imglbl1 , imglbl2 , imglbl ,imglbl3,imglbl4 ,imglbl5,namlbl,imglbl7,imglbl8,namlbl2;
    
    
    JButton opbtn,opbtn1 ,vwbtn, vwbtn1,vwbtn2,vwbtn3 ,vwbtn4,vwbtn5,vwbtn6;
    Color mycolor ;
    Font myFont ,myFont1;
    ImageIcon img ,img1,img2,img3,img4 ,img5,img6;
    public static boolean isLoggedIn = false;
    

    public Frontpage1 () {
        super ( "Magic Screen");
        this.setSize(1100,600);
        this.setLocationRelativeTo(null);
        setResizable(false);
img = new ImageIcon("image/e.PNG");


        mycolor = new Color(48,12,77);
        
      
        
        myFont = new Font("Cambria",Font.PLAIN,18);
        
        myFont1 = new Font("Cambria",Font.BOLD,13);
 
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(mycolor);

        imglbl7 = new JLabel(img);
        imglbl7.setBounds(0,0,50,50);
        
        imglbl7.setBackground(mycolor);
        imglbl7.setOpaque(true);
        
        panel.add(imglbl7);
       
        imglbl8 = new JLabel(img2);
        imglbl8.setBounds(1050,0,50,50);
        
        imglbl8.setBackground(mycolor);
        imglbl8.setOpaque(true);
        
        panel.add(imglbl8);



namlbl = new JLabel("Magic Screen");
namlbl.setBounds(60, 0, 1100, 40);
namlbl.setOpaque(true);
namlbl.setFont(myFont1);
namlbl.setBackground(mycolor);
namlbl.setForeground(Color.WHITE);
panel.add(namlbl);


namlbl2 = new JLabel("New Arrival.....");
namlbl2.setBounds(48, 295, 1100, 30);
namlbl2.setOpaque(true);
namlbl2.setFont(myFont1);
namlbl2.setBackground(mycolor);
namlbl2.setForeground(Color.WHITE);
panel.add(namlbl2);



    
        img1 = new ImageIcon("image/f.JPG");
        imglbl = new JLabel(img1);
        imglbl.setBounds(50,40,1000,260);
        
        imglbl.setOpaque(true);
        panel.add(imglbl);

        
        img2 = new ImageIcon("image/g.JPG");
        imglbl1 = new JLabel(img2);
        imglbl1.setBounds(50,330 ,160 ,200);
        imglbl1.setBackground(mycolor);
        imglbl1.setOpaque(true);
        
        panel.add(imglbl1);

 
        img3 = new ImageIcon("image/h.JPEG");
        imglbl2 = new JLabel(img3);
        imglbl2.setBounds(260,330 ,160,200);
         imglbl2.setBackground(mycolor);
        imglbl2.setOpaque(true);
        
        panel.add(imglbl2);

        img4 = new ImageIcon("image/i.JPG");
        imglbl3 = new JLabel(img4);
        imglbl3.setBounds(470,330 ,160 ,200);
         imglbl3.setBackground(mycolor);
        imglbl3.setOpaque(true);
        
        panel.add(imglbl3);

         img5 = new ImageIcon("image/j.JPG");
        imglbl4 = new JLabel(img5);
        imglbl4.setBounds(680,330 ,160 ,200);
         imglbl4.setBackground(mycolor);
        imglbl4.setOpaque(true);
        
        panel.add(imglbl4);

         img6 = new ImageIcon("image/k.JPEG");
        imglbl5 = new JLabel(img6);
        imglbl5.setBounds(890,330 ,160,200);
         imglbl5.setBackground(mycolor);
        imglbl5.setOpaque(true);
        
        panel.add(imglbl5); 
        
    
 vwbtn = new JButton(img1);
        vwbtn.setBounds(50, 40, 1000, 250);
        vwbtn.setBackground(mycolor);
         vwbtn.addActionListener(this);
        panel.add(vwbtn);

;


        opbtn = new JButton("Log in");
        opbtn.setBounds(1000, 0, 80, 30);
        opbtn.setBackground(mycolor);
         opbtn.setFont(myFont1);
    opbtn.setForeground(Color.WHITE);
         opbtn.addActionListener(this);
     
        panel.add(opbtn);


        opbtn1 = new JButton("Sign up");
        opbtn1.setBounds(900, 0, 80, 30);
        opbtn1.setBackground(mycolor);
         opbtn1.setFont(myFont1);
    opbtn1.setForeground(Color.WHITE);
          
        opbtn1.addActionListener(this);
        panel.add(opbtn1);


        


        vwbtn1 = new JButton( "view ");
        vwbtn1.setBounds(50, 530, 160, 30);
        vwbtn1.setBackground(mycolor);
        vwbtn1.setForeground(Color.WHITE);
        vwbtn1.setFocusable(false);
        vwbtn1.setFont(myFont);
        vwbtn1.addActionListener(this);
        panel.add (vwbtn1);


 vwbtn2 = new JButton( "view ");
        vwbtn2.setBounds(260,530 , 160, 30);
        vwbtn2.setBackground(mycolor);
        vwbtn2.setForeground(Color.WHITE);
        vwbtn2.setFont(myFont);
        vwbtn2.setFocusable(false);
        vwbtn2.addActionListener(this);
        panel.add (vwbtn2);

 vwbtn3 = new JButton( "view ");
        vwbtn3.setBounds(470,530, 160, 30);
        vwbtn3.setBackground(mycolor);
        vwbtn3.setForeground(Color.WHITE);
        vwbtn3.setFont(myFont);
        vwbtn3.setFocusable(false);
        vwbtn3.addActionListener(this);
        panel.add (vwbtn3);

 vwbtn4 = new JButton( "view ");
        vwbtn4.setBounds(680,530 , 160, 30);
        vwbtn4.setBackground(mycolor);
        vwbtn4.setForeground(Color.WHITE);
        vwbtn4.setFont(myFont);
        vwbtn4.setFocusable(false);
        vwbtn4.addActionListener(this);
        panel.add (vwbtn4);


        vwbtn5 = new JButton( "view ");
        vwbtn5.setBounds(890,530 , 160, 30);
        vwbtn5.setBackground(mycolor);
        vwbtn5.setForeground(Color.WHITE);
        vwbtn5.setFont(myFont);
        vwbtn5.setFocusable(false);
        vwbtn5.addActionListener(this);
        panel.add (vwbtn5);

this.add(panel);
panel.setLayout(null);
setVisible(true);

        
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == opbtn) {
            new LoginPage();
            this.setVisible(false);
        } else if (e.getSource() == opbtn1) {
            new SignUpPage();
            this.setVisible(false);
        } else if (e.getSource() == vwbtn) {
            if (!isLoggedIn) {
             this.setVisible(false);
                new LoginPage();
            } else {
                this.setVisible(false);
                StrangerThings s1= new StrangerThings();
                s1.setVisible(true);
            }
        } else if (e.getSource() == vwbtn1) {
            if (!isLoggedIn) {
             
                new LoginPage();
                this.setVisible(false);
               
            } else {
                this.setVisible(false);
                Avatar a1 = new Avatar();
                a1.setVisible(true);
            }
        } else if (e.getSource() == vwbtn2) {
            if (!isLoggedIn) {
             
                new LoginPage();
                this.setVisible(false);
            } else {
                this.setVisible(false);
                Death d1 = new Death();
                d1.setVisible(true);
            }
        } else if (e.getSource() == vwbtn3) {
            if (!isLoggedIn) {
             
                new LoginPage();
                this.setVisible(false);
            } else {
                this.setVisible(false);
                It i1 = new It();
                i1.setVisible(true);
            }
        } else if (e.getSource() == vwbtn4) {
            if (!isLoggedIn) {
            
                new LoginPage();
                this.setVisible(false);
            } else {
                this.setVisible(false);
                Bleach b1 = new Bleach();
                b1.setVisible(true);
            }
        } else if (e.getSource() == vwbtn5) {
            if (!isLoggedIn) {
             
                new LoginPage();
                this.setVisible(false);
            } else {
                this.setVisible(false);
                Dragon d1 = new Dragon();
                d1.setVisible(true);
            }
        }
    }

    public void mouseClicked(MouseEvent e) {
        if (!isLoggedIn) {
            new LoginPage();
            this.setVisible(false);
        } else {
            if (e.getSource() == imglbl) {
                this.setVisible(false);
                StrangerThings s1= new StrangerThings();
                s1.setVisible(true);
            } else if (e.getSource() == imglbl1) {
                this.setVisible(false);
                Avatar a1 = new Avatar();
                a1.setVisible(true);
            } else if (e.getSource() == imglbl2) {
                this.setVisible(false);
                Death d1 = new Death();
                d1.setVisible(true);
            } else if (e.getSource() == imglbl3) {
                this.setVisible(false);
                It i1 = new It();
                i1.setVisible(true);
            } else if (e.getSource() == imglbl4) {
                this.setVisible(false);
                Bleach b1 = new Bleach();
                b1.setVisible(true);
            } else if (e.getSource() == imglbl5) {
                this.setVisible(false);
                Dragon d1 = new Dragon();
                d1.setVisible(true);
            }
        }
    }
    public void mousePressed(MouseEvent e) {
    }
    public void mouseReleased(MouseEvent e) {
    }
    public void mouseEntered(MouseEvent e) {
    }   
    public void mouseExited(MouseEvent e) {
    }
   
}

    

